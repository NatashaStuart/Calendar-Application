app.directive('myEventAddForm', function() {
  return {
     /**
     * location of the HTML structure to use with this directive, similar to what a View is to a Controller
    */
    templateUrl: 'scripts/directives/calendar/event-add-form.html',
    
     /**
     * Allows the deleloper to see in the consol log what is happening. 
     */
     
    link: function (scope, element, attributes) 
    {
      
      console.log('myEventAddForm directive has loaded.');
      console.log('myEventAddForm directive: scope: ', scope);
      console.log('myEventAddForm directive: element: ', element);
      console.log('myEventAddForm directive: attributes: ', attributes);
      
      // make the form's angularjs variable available to the parent (CalendarController)'s scope, because it currently only exists inside this directive
      scope.$parent.addEventForm = scope.addEventForm;
    }
  };
  });