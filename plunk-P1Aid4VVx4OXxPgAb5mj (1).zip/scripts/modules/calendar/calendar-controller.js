//This Bootstrap Calendar plug-in came from 'http://mattlewis92.github.io/angular-bootstrap-calendar/'
app.controller ('CalendarController', ['AuthenticationService', '$localStorage', 'alert', '$scope', function(auth, $localStorage, alert, $scope) 
  {
    
var vm = this;

    $scope.eventName = 'Event Name Here';
    $scope.calendarView = 'Events'; 
    $scope.eventIndex = -1;
    $scope.newEvent = {
      content: ''
    };
     $scope.newEvent = {
      name: ''
    };
   
    $scope.searchFilters = '';
    $scope.searchResults = []; 
    
    var _initialise = function () {
      
      console.log("ForumController: _initialise() is running.");
      
      if (!$localStorage.calendarData) {
        
        $localStorage.calendarData = [];
        
        // set up the mock data
        _SetForumMockData();
        
      }
      
    };
    
    $scope.DoSearch = function () {
      
      $scope.searchResults = [];
      
      // get filters
      var filters = $scope.searchFilters.split(' ');
      
      for (var i = 0; i < $scope.calendarData().length; i++) {
        
        var event = $scope.calendarData()[i];
        var posts = event.posts;
        
        for (var j = 0; j < posts.length; j++) {
          
          var post = posts[j];
          var postContent = post.content;
          
          for (var k = 0; k < filters.length; k++) {
            
            var filter = filters[k].toLowerCase();
            
            if (filter.length < 3) continue;
            
            if (postContent.toLowerCase().indexOf(filter) > -1) {
              
              // we found a match!
              var result = {
                eventIndex: i,
                eventTitle: event.name,
                postContent: postContent,
                postUser: post.user,
                postDate: post.date
              };
              
              $scope.searchResults.push(result);
              
            }
            
          }
          
        }
        
      }
      
    };
    
    $scope.calendarData = function () {
      
      return $localStorage.calendarData;
      
    };

    vm.calendarView = 'month';
    vm.viewDate = new Date();
    vm.cellIsOpen = true;
    vm.events = [];
    vm.calendarTitle = moment().format('MMMM');

    vm.addEvent = function() {
      vm.events.push({
        title: 'New event',
        startsAt: moment().startOf('day').toDate(),
        endsAt: moment().endOf('day').toDate(),
        color: '',
        draggable: true,
        resizable: true
      });
    };
    
 //$localStorage.calendarData[events].push(post);
 
    vm.eventClicked = function(event) {
      alert.show('Clicked', event);
    };

    vm.eventEdited = function(event) {
      alert.show('Edited', event);
    };

    vm.eventDeleted = function(event) {
      alert.show('Deleted', event);
    };

    vm.eventTimesChanged = function(event) {
      alert.show('Dropped or resized', event);
    };

    vm.toggle = function($event, field, event) {
      $event.preventDefault();
      $event.stopPropagation();
      event[field] = !event[field];
    };

    vm.timespanClicked = function(date, cell) {

      if (vm.calendarView === 'month') {
        if ((vm.cellIsOpen && moment(date).startOf('day').isSame(moment(vm.viewDate).startOf('day'))) || cell.events.length === 0 || !cell.inMonth) {
          vm.cellIsOpen = false;
        } else {
          vm.cellIsOpen = true;
          vm.viewDate = date;
        }
      } else if (vm.calendarView === 'year') {
        if ((vm.cellIsOpen && moment(date).startOf('month').isSame(moment(vm.viewDate).startOf('month'))) || cell.events.length === 0) {
          vm.cellIsOpen = false;
        } else {
          vm.cellIsOpen = true;
          vm.viewDate = date;
        }
      }
      
      vm.calendarTitle = moment(date).format('MMMM');

    };

  }]);
  
  
  
  function _SetForumMockData() {
      
      console.log("CalendarController: _SetForumMockData() is running.");
  
  $localStorage.calendarData = [
        {
         title: 'Dentist',
         startsAt: moment().startOf('day').add(7, 'hours').toDate(),
         endsAt: moment().startOf('day').add(19, 'hours').toDate(),
         draggable: true,
         resizable: true
        },
        {
         title: 'Work',
         startsAt: moment().startOf('day').add(10, 'hours').toDate(),
         endsAt: moment().startOf('day').add(21, 'hours').toDate(),
         draggable: true,
         resizable: true,
        }
      ];
  }
      

app
  .factory('alert', function($uibModal) {

    function show(action, event) {
      return $uibModal.open({
        templateUrl: 'modalContent.html',
        controller: function() {
          var vm = this;
          vm.action = action;
          vm.event = event;
        },
        controllerAs: 'vm'
      });
    }

    return {
      show: show
    };

  });