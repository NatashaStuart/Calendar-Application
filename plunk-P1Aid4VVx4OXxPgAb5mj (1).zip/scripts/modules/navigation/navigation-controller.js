app.controller ('NavigationController', [
	'$scope', 'AuthenticationService', '$location', function ( $scope, auth, $location )
	{
	  
	  /** oputput parameter values to console for debug purposes **/
    console.log('NavigationController has loaded.');
    console.log('$scope:', $scope);
		  
    /****** CONTROLLER CODE ******/
    
    /** public attributes / variables **/
    //
    
    /** private attributes / variables **/
    //
    
    /** constructor / startup method **/
    var _initialise = function () {
      //
    }
    
    /** public behaviour / methods **/
    $scope.User = function () { return auth.User(); };
    
    $scope.isLoggedIn = function () {
      return (auth.User() !== null);
    }
    
    $scope.isActiveLink = function (link) {
      return $location.path() === link;
    };
    
    /** private behaviour / methods **/
    //
    
    /** run the constructor / startup method **/
    _initialise();
	  
	}
]);