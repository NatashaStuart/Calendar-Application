app.controller('RegistrationController', [
  '$scope', '$timeout', 'AuthenticationService', '$location',
  function($scope, $timeout, auth, $location) {

    /** oputput parameter values to console for debug purposes **/
    console.log('RegistrationController has loaded.');

    /****** CONTROLLER CODE ******/

    /** public ($scope) variables **/
    $scope.user = {
      email: '',
      password: '',
      passwordConfirm: '',
      name: ''
    };

    /** private variables **/
    // 

    /** constructor **/
    var _initialise = function() {
      //
    };

    /** public ($scope) methods **/
    $scope.RegisterUser = function() {

      var proceed = true;

      // checks if email already exists
      if (auth.GetUserByEmail($scope.user.email) != null) {

        // if email exists
        proceed = false;

      }

      // checks if passwords matches
      if ($scope.user.password != $scope.user.passwordConfirm) {

        // if passwords don't match
        proceed = false;

      }

      if (!proceed) {

        return;
      }

      // creates a new user object
      var user = {
        email: $scope.user.email,
        password: auth.EncryptPassword($scope.user.password),
        name: $scope.user.name
      };

      // adds to authentication's users' database
      auth.AddUser(user);

      // logs in the user using the non-encrypted password
      auth.AuthenticateUser(user.email, $scope.user.password);

      // redirects to the calendar straight away
      $location.path("/calendar");

    };

    // In the future this would only display to users with admin privileges
    $scope.ShowAllUsers = function() {

      return auth.GetAllUsers();

    };

    /** private methods **/
    //

    /** initialise controller **/
    _initialise();

  }
]);