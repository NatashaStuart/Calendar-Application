app.controller ('ProfileController', [
	'$scope', 'AuthenticationService',  '$http', '$sce', function ( $scope, auth, $http, $sce )
	{
		  
    /** oputput parameter values to console for debug purposes **/
    console.log('ProfileController has loaded.');
    console.log('$scope:', $scope);
		  
    /****** CONTROLLER CODE ******/
    
    /** public attributes / variables **/
    $scope.profileFormModel = {
      name: auth.User().name, // make form field contain the user's name at the start
      email: auth.User().email, // make form field contain the user's email at the start
      password: '',
      newPassword: '',
      passwordConfirm: '',
      imageURL: ''
    };
    $scope.invalidCurrentPassword = false;
    // the !! operator converts any value into its "truthy" boolean equivalent - TRUE if it has a value, FALSE otherwise
    $scope.userImageSet = !!auth.User().image;
    
    /** private attributes / variables **/
    //
    
    /** constructor / startup method **/
    var _initialise = function () {
      //
    }
    
    /** public behaviour / methods **/
    $scope.User = function () { 
      return auth.User();
    };
    
    $scope.UpdateUserProfile = function () {
      
      // check existing password
      $scope.invalidCurrentPassword = !auth.AuthenticateUser($scope.User().email, $scope.profileFormModel.password);
      
      // if incorrect, then ...
      if ($scope.invalidCurrentPassword) {
        
        // invalid current password
        return;
        
      } 
      
      // check if the new password matches the confirm password field
      if ($scope.profileFormModel.newPassword !== '' && $scope.profileFormModel.newPassword !== $scope.profileFormModel.passwordConfirm) {
        
        // new password was supplied and the two sets do not match
        return;
        
      }
      
      // compile the user data
      var userData = {
        name: $scope.profileFormModel.name,
        email: $scope.profileFormModel.email
      };
      
      // if new password was supplied, then include it in the userData object
      if ($scope.profileFormModel.newPassword !== '') {
        
        // encrypt the password
        userData.password = auth.EncryptPassword($scope.profileFormModel.newPassword);
        
        // empty the new password view fields
        $scope.profileFormModel.newPassword = '';
        $scope.profileFormModel.passwordConfirm = '';
        
      }
      
      // empty the password view field
      $scope.profileFormModel.password = '';
      
       // check if user selected an image from their hard drive
      // angular.element allows us to get a handle on this particular input HTML field
      // [0] gives us direct access to the JavaScript DOM representation of this input field, so we can access the image file
      var imageField = angular.element("#image")[0];
      
	    // imageField.files => array containing the user's chosen files as known to the input element
	    // imageField.files[0] => first image in the array
	    //    (if configured, the input/file can accept multiple images at once, not the case here, but always an array even if just one file)
	    // in our case, the user only ever uploads one image at a time, so we access that
      if (imageField.files[0]) {
        
        //console.log(imageField.files[0]);
        
        var img = imageField.files[0];
        
        // validate size
        //if (img.size <= 100 * 1024) {
        
          UploadImage(imageField.files[0]);
        
        //} else {
          
          // error
          
        //}
        
      }
      
      // otherwise, check if they supplied an image URL
      else if ($scope.profileFormModel.imageURL) {
        
        // fetch the image and save it
        UploadImageURL($scope.profileFormModel.imageURL);
        
        // clear out the form field
        $scope.profileFormModel.imageURL = '';
        
      }
      
      // reset form validation status - https://stackoverflow.com/questions/18648427/angular-clear-subform-data-and-reset-validation
      $scope.profileForm.$setPristine();
      $scope.profileForm.$setUntouched();
      
      // tell auth to update the user data
      auth.UpdateUserData(userData);
      
    };
    
    var UploadImage = function (imageFile) {
		    
	    // Using FileReader to display the image content
      var reader = new FileReader();
      
      // when the file reader has accessed the entire file, display it
      reader.onload = function(e) {
            
        // get the base64 encoded string making up the image
        // see here for more info: http://www.bigfastblog.com/embed-base64-encoded-images-inline-in-html
        var imgSrc = e.target.result;
        
        SaveUserImage(imgSrc);
        
      };
        
      // load the file => once ready, it will run the above function attached to 'reader.onload'
      reader.readAsDataURL(imageFile);
        
    };
    
    var UploadImageURL = function (imageURL) {
      
      $http.defaults.useXDomain = true;
      
      $http({
        method: 'GET',
        url: $sce.trustAsResourceUrl(imageURL),
        responseType: 'arraybuffer'
      }).then(function(response) {
        
        // source: https://stackoverflow.com/a/35514768
        var blob = new Blob([ response.data ], { type: 'image/jpg' });
        
        // make use of the HTML5 file reader
        var reader = new window.FileReader();
        
        // pass the image raw source to the reader
        reader.readAsDataURL(blob); 
        
        // once the reader has parsed it, save it as the user's profile image
        reader.onloadend = function() {
          
          var imgSrc = reader.result;
          
          SaveUserImage(imgSrc);
          
        }
        
      }, function (error) {
        console.log('http get error', error);
      });
      
    };
    
    var SaveUserImage = function (imgSrc) {
      
      // finally, save the preference for later
      // save it for later
      var userData = {
        image: imgSrc,
      };
      
      // tell auth to update the user data
      auth.UpdateUserData(userData);
      
      // allow the image preview to display
      $scope.userImageSet = true;
      
      // force angular to refresh the UI to reflect changes
	    $scope.$apply();
      
    }
    
    /** private behaviour / methods **/
    //
    
    /** run the constructor / startup method **/
    _initialise();

	}
]);