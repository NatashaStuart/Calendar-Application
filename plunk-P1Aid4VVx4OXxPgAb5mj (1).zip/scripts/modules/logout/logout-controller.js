app.controller ('LogoutController', [
	'AuthenticationService' ,'$location', function ( auth, $location )
	{
	  
	  auth.Logout();
	  
	  $location.path('/home');
	  
	}
]);