app.controller ('HomeController', [
	'$scope', 'AuthenticationService',  function ( $scope, auth )
	{
		  
    /** oputput parameter values to console for debug purposes **/
    console.log('HomeController has loaded.');
    console.log('$scope:', $scope);
		  
    /****** CONTROLLER CODE ******/
    
    /** public attributes / variables **/
    // 
    
    /** private attributes / variables **/
    //
    
    /** constructor / startup method **/
    var _initialise = function () {
      //
    }
    
    /** public behaviour / methods **/
    $scope.User = function () { 
      return auth.User();
    };
    
    /** private behaviour / methods **/
    //
    
    /** run the constructor / startup method **/
    _initialise();

	}
]);
