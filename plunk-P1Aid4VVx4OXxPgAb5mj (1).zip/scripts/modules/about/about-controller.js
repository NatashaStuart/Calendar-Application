//google.maps.event.addDomListener(window, 'load', initMap);

app.controller('AboutController', [
  '$scope',
  function($scope) {


// Google map plugin

    window.initMap = function() {
      var europe = new google.maps.LatLng(52.203216, 0.135290);
      var mapOptions = {
        zoom: 4,
        center: europe
      }
      var map = new google.maps.Map(document.getElementById('map-canvas'), mapOptions);

      var marker = new google.maps.Marker({
        map: map,
        position: europe,
        title: 'Hello World!'
      });

      var markers = {};
      var i = 0;

      google.maps.event.addListener(map, 'click', function(event) {
        var lat = event.latLng.lat() - 0,
          lng = event.latLng.lng() - 0;

        var existingMarkers = Object.keys(markers);
        for (var index in existingMarkers) {
          var key = existingMarkers[index];
          markers[key].setMap(null);
          delete markers[key];
        }

        for (max = i + 1; i < max; i++) {
          var latlng = new google.maps.LatLng(lat += 0.1, lng += 0.1);
          markers[i] = new google.maps.Marker({
            position: latlng,
            map: map
          });
        }

        console.log("Currently we have " + Object.keys(markers).length + " markers");
      });

    }

  }
]);