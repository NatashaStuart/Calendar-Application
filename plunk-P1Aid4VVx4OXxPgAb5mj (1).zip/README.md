### Instructions on how to use this Calendar Application
This application was created as an assessment piece for the module Mobile Technology, MOD002663.

This application is can be used to help organise your time and keep track of upcoming events.

You must register and login to use this app. 
